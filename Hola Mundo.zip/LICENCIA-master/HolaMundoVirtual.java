
package hola.mundo.virtual;

/**
 *
 * @author LABING14
 */
public class HolaMundoVirtual {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
       System.out.println ("hola mundo virtual este es  mi primer proyecto en java ");
        
    }
    
}
